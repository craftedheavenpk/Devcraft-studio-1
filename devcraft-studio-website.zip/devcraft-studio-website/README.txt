DEVCRAFT STUDIO WEBSITE STARTER

Files:
- index.html: responsive single-page website with service sections, package pricing, FAQ and project order form.

How the order system works:
- The form validates required client fields in the browser.
- On submit, it builds a detailed project brief and opens WhatsApp chat to +92 303 4812714.
- This starter does not store orders in a database or provide a private admin dashboard. To add persistent order records, login/admin access, file uploads or online payment, connect a backend/database (for example Supabase) and deploy it with appropriate security rules.

Deployment:
- Open index.html locally to preview.
- For GitHub Pages, upload index.html to the root of a repository and enable Pages in repository settings.
- Before publishing, replace illustrative portfolio cards with real completed projects, and confirm package scope, hosting/domain terms and legal policies.

Pricing included from the supplied proposal:
Basic Rs. 2,500; Standard Rs. 3,500; Professional Rs. 5,000; Premium Aura Rs. 7,000+.
Daraz Store Setup Rs. 5,500 with 10–15 day estimated delivery as specified in the brief.
